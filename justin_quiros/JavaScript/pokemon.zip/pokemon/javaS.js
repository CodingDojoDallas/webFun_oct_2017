$(document).ready(function(){
		for(var i = 151; i > 0; i--){
		$('#container').append('<img src="http://pokeapi.co/media/img/' + i + '.png">');
		// console.log();
		}
	});
